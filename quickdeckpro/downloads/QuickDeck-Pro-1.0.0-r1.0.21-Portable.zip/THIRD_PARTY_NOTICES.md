# Componentes de terceros

QuickDeck Pro incluye código y bibliotecas de terceros. El código propio de las compilaciones a partir de 0.1.4, incluida la edición pública v0.1.1 (compilación 0.1.6), está sujeto a la licencia propietaria de uso y distribución del archivo `LICENSE`. Las restricciones del producto no modifican los permisos de los componentes de terceros. Las declaraciones de licencia y avisos suministrados por los paquetes están en el directorio adjunto `licenses/`. Este inventario incluye dependencias transitivas y herramientas de compilación; no implica que todo paquete enumerado se enlace o ejecute en Windows.

La biblioteca estándar de Rust conserva sus avisos en `licenses/rust-standard-library/`; el runtime MinGW conserva su aviso propio. Segoe UI se usa desde Windows y no se redistribuye como archivo de fuente. WebView2 es un requisito de Microsoft que gestiona su propio instalador y licencia.

| Ecosistema | Componente | Versión | Declaración de licencia del paquete | Proyecto |
| --- | --- | --- | --- | --- |
| Rust | adler2 | 2.0.1 | 0BSD OR MIT OR Apache-2.0 | https://github.com/oyvindln/adler2 |
| Rust | aho-corasick | 1.1.5 | Unlicense OR MIT | https://github.com/BurntSushi/aho-corasick |
| Rust | alloc-no-stdlib | 3.0.0 | BSD-3-Clause | https://github.com/dropbox/rust-alloc-no-stdlib |
| Rust | alloc-stdlib | 0.3.0 | BSD-3-Clause | https://github.com/dropbox/rust-alloc-no-stdlib |
| Rust | anyhow | 1.0.104 | MIT OR Apache-2.0 | https://github.com/dtolnay/anyhow |
| Rust | atomic-waker | 1.1.2 | Apache-2.0 OR MIT | https://github.com/smol-rs/atomic-waker |
| Rust | autocfg | 1.5.1 | Apache-2.0 OR MIT | https://github.com/cuviper/autocfg |
| Rust | base64 | 0.23.1 | MIT OR Apache-2.0 | https://github.com/marshallpierce/rust-base64 |
| Rust | bit-set | 0.8.0 | Apache-2.0 OR MIT | https://github.com/contain-rs/bit-set |
| Rust | bit-vec | 0.8.0 | Apache-2.0 OR MIT | https://github.com/contain-rs/bit-vec |
| Rust | bitflags | 2.13.2 | MIT OR Apache-2.0 | https://github.com/bitflags/bitflags |
| Rust | block-buffer | 0.10.4 | MIT OR Apache-2.0 | https://github.com/RustCrypto/utils |
| Rust | brotli | 9.1.1 | BSD-3-Clause AND MIT | https://github.com/dropbox/rust-brotli |
| Rust | brotli-decompressor | 6.3.0 | BSD-3-Clause/MIT | https://github.com/dropbox/rust-brotli-decompressor |
| Rust | bs58 | 0.5.1 | MIT/Apache-2.0 | https://github.com/Nullus157/bs58-rs |
| Rust | bumpalo | 3.20.3 | MIT OR Apache-2.0 | https://github.com/fitzgen/bumpalo |
| Rust | bytemuck | 1.25.2 | Zlib OR Apache-2.0 OR MIT | https://github.com/Lokathor/bytemuck |
| Rust | byteorder | 1.5.0 | Unlicense OR MIT | https://github.com/BurntSushi/byteorder |
| Rust | byteorder-lite | 0.1.0 | Unlicense OR MIT | https://github.com/image-rs/byteorder-lite |
| Rust | bytes | 1.12.1 | MIT | https://github.com/tokio-rs/bytes |
| Rust | bzip2 | 0.6.1 | MIT OR Apache-2.0 | https://github.com/trifectatechfoundation/bzip2-rs |
| Rust | camino | 1.2.6 | MIT OR Apache-2.0 | https://github.com/camino-rs/camino |
| Rust | cargo-platform | 0.1.9 | MIT OR Apache-2.0 | https://github.com/rust-lang/cargo |
| Rust | cargo_metadata | 0.19.2 | MIT | https://github.com/oli-obk/cargo_metadata |
| Rust | cargo_toml | 1.0.1 | Apache-2.0 OR MIT | https://gitlab.com/lib.rs/cargo_toml |
| Rust | cc | 1.11.1 | MIT OR Apache-2.0 | https://github.com/rust-lang/cc-rs |
| Rust | cfb | 0.14.0 | MIT | https://github.com/mdsteele/rust-cfb |
| Rust | cfg-if | 1.0.5 | MIT OR Apache-2.0 | https://github.com/rust-lang/cfg-if |
| Rust | chacha20 | 0.10.2 | MIT OR Apache-2.0 | https://github.com/RustCrypto/stream-ciphers |
| Rust | chrono | 0.4.45 | MIT OR Apache-2.0 | https://github.com/chronotope/chrono |
| Rust | clipboard-win | 5.4.3 | BSL-1.0 | https://github.com/DoumanAsh/clipboard-win |
| Rust | constant_time_eq | 0.6.1 | CC0-1.0 OR MIT-0 OR Apache-2.0 | https://codeberg.org/cesarb/constant_time_eq |
| Rust | cookie | 0.18.2 | MIT OR Apache-2.0 | https://github.com/SergioBenitez/cookie-rs |
| Rust | cpufeatures | 0.2.17 | MIT OR Apache-2.0 | https://github.com/RustCrypto/utils |
| Rust | cpufeatures | 0.3.1 | MIT OR Apache-2.0 | https://github.com/RustCrypto/utils |
| Rust | crc32fast | 1.5.4 | MIT OR Apache-2.0 | https://github.com/srijs/rust-crc32fast |
| Rust | crossbeam-channel | 0.5.17 | MIT OR Apache-2.0 | https://github.com/crossbeam-rs/crossbeam |
| Rust | crossbeam-utils | 0.8.23 | MIT OR Apache-2.0 | https://github.com/crossbeam-rs/crossbeam |
| Rust | crypto-common | 0.1.7 | MIT OR Apache-2.0 | https://github.com/RustCrypto/traits |
| Rust | cssparser | 0.37.0 | MPL-2.0 | https://github.com/servo/rust-cssparser |
| Rust | cssparser-macros | 0.7.1 | MPL-2.0 | https://github.com/servo/rust-cssparser |
| Rust | ctor | 1.0.13 | Apache-2.0 OR MIT | https://github.com/mmastrac/linktime |
| Rust | darling | 0.24.1 | MIT | https://github.com/TedDriggs/darling |
| Rust | darling_core | 0.24.1 | MIT | https://github.com/TedDriggs/darling |
| Rust | darling_macro | 0.24.1 | MIT | https://github.com/TedDriggs/darling |
| Rust | deranged | 0.5.9 | MIT OR Apache-2.0 | https://github.com/jhpratt/deranged |
| Rust | derive_more | 2.1.1 | MIT | https://github.com/JelteF/derive_more |
| Rust | derive_more-impl | 2.1.1 | MIT | https://github.com/JelteF/derive_more |
| Rust | digest | 0.10.7 | MIT OR Apache-2.0 | https://github.com/RustCrypto/traits |
| Rust | dirs | 7.0.0 | MIT OR Apache-2.0 | https://codeberg.org/dirs/dirs-rs |
| Rust | dirs-sys | 0.5.0 | MIT OR Apache-2.0 | https://github.com/dirs-dev/dirs-sys-rs |
| Rust | displaydoc | 0.2.7 | MIT OR Apache-2.0 | https://github.com/yaahc/displaydoc |
| Rust | dom_query | 0.28.0 | MIT | https://github.com/niklak/dom_query |
| Rust | dpi | 0.1.2 | Apache-2.0 AND MIT | https://github.com/rust-windowing/winit |
| Rust | dtoa | 1.0.11 | MIT OR Apache-2.0 | https://github.com/dtolnay/dtoa |
| Rust | dtoa-short | 0.3.5 | MPL-2.0 | https://github.com/upsuper/dtoa-short |
| Rust | dunce | 1.0.5 | CC0-1.0 OR MIT-0 OR Apache-2.0 | https://gitlab.com/kornelski/dunce |
| Rust | dyn-clone | 1.0.20 | MIT OR Apache-2.0 | https://github.com/dtolnay/dyn-clone |
| Rust | embed-resource | 3.0.12 | MIT | https://github.com/nabijaczleweli/rust-embed-resource |
| Rust | equivalent | 1.0.3 | Apache-2.0 OR MIT | https://github.com/indexmap-rs/equivalent |
| Rust | erased-serde | 0.4.11 | MIT OR Apache-2.0 | https://github.com/dtolnay/erased-serde |
| Rust | error-code | 3.4.0 | BSL-1.0 | https://github.com/DoumanAsh/error-code |
| Rust | fallible-iterator | 0.3.0 | MIT/Apache-2.0 | https://github.com/sfackler/rust-fallible-iterator |
| Rust | fallible-streaming-iterator | 0.1.9 | MIT/Apache-2.0 | https://github.com/sfackler/fallible-streaming-iterator |
| Rust | fastrand | 2.5.0 | Apache-2.0 OR MIT | https://github.com/smol-rs/fastrand |
| Rust | fdeflate | 0.3.7 | MIT OR Apache-2.0 | https://github.com/image-rs/fdeflate |
| Rust | filetime | 0.2.29 | MIT/Apache-2.0 | https://github.com/alexcrichton/filetime |
| Rust | find-msvc-tools | 0.1.15 | MIT OR Apache-2.0 | https://github.com/rust-lang/cc-rs |
| Rust | flate2 | 1.1.11 | MIT OR Apache-2.0 | https://github.com/rust-lang/flate2-rs |
| Rust | fnv | 1.0.7 | Apache-2.0 / MIT | https://github.com/servo/rust-fnv |
| Rust | foldhash | 0.2.0 | Zlib | https://github.com/orlp/foldhash |
| Rust | form_urlencoded | 1.2.2 | MIT OR Apache-2.0 | https://github.com/servo/rust-url |
| Rust | futures-channel | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-core | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-io | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-macro | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-sink | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-task | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | futures-util | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs |
| Rust | generic-array | 0.14.7 | MIT | https://github.com/fizyk20/generic-array.git |
| Rust | getrandom | 0.2.17 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom |
| Rust | getrandom | 0.3.4 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom |
| Rust | getrandom | 0.4.3 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom |
| Rust | glob | 0.3.4 | MIT OR Apache-2.0 | https://github.com/rust-lang/glob |
| Rust | global-hotkey | 0.8.0 | Apache-2.0 OR MIT | https://github.com/tauri-apps/global-hotkey |
| Rust | hashbrown | 0.12.3 | MIT OR Apache-2.0 | https://github.com/rust-lang/hashbrown |
| Rust | hashbrown | 0.17.1 | MIT OR Apache-2.0 | https://github.com/rust-lang/hashbrown |
| Rust | hashlink | 0.12.2 | MIT OR Apache-2.0 | https://github.com/djc/hashlink |
| Rust | heck | 0.5.0 | MIT OR Apache-2.0 | https://github.com/withoutboats/heck |
| Rust | hex | 0.4.3 | MIT OR Apache-2.0 | https://github.com/KokaKiwi/rust-hex |
| Rust | html5ever | 0.39.0 | MIT OR Apache-2.0 | https://github.com/servo/html5ever |
| Rust | http | 1.5.0 | MIT OR Apache-2.0 | https://github.com/hyperium/http |
| Rust | http-body | 1.1.0 | MIT | https://github.com/hyperium/http-body |
| Rust | http-body-util | 0.1.5 | MIT | https://github.com/hyperium/http-body |
| Rust | httparse | 1.10.1 | MIT OR Apache-2.0 | https://github.com/seanmonstar/httparse |
| Rust | hyper | 1.12.0 | MIT | https://github.com/hyperium/hyper |
| Rust | hyper-rustls | 0.27.10 | Apache-2.0 OR ISC OR MIT | https://github.com/rustls/hyper-rustls |
| Rust | hyper-util | 0.1.21 | MIT | https://github.com/hyperium/hyper-util |
| Rust | ico | 0.6.0 | MIT | https://github.com/mdsteele/rust-ico |
| Rust | icu_collections | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_locale_core | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_normalizer | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_normalizer_data | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_properties | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_properties_data | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | icu_provider | 2.4.0 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | ident_case | 1.0.1 | MIT/Apache-2.0 | https://github.com/TedDriggs/ident_case |
| Rust | idna | 1.1.0 | MIT OR Apache-2.0 | https://github.com/servo/rust-url/ |
| Rust | idna_adapter | 1.2.2 | Apache-2.0 OR MIT | https://github.com/hsivonen/idna_adapter |
| Rust | image | 0.25.10 | MIT OR Apache-2.0 | https://github.com/image-rs/image |
| Rust | indexmap | 1.9.3 | Apache-2.0 OR MIT | https://github.com/bluss/indexmap |
| Rust | indexmap | 2.14.2 | Apache-2.0 OR MIT | https://github.com/indexmap-rs/indexmap |
| Rust | infer | 0.22.0 | MIT | https://github.com/bojand/infer |
| Rust | ipnet | 2.12.2 | MIT OR Apache-2.0 | https://github.com/krisprice/ipnet |
| Rust | itoa | 1.0.18 | MIT OR Apache-2.0 | https://github.com/dtolnay/itoa |
| Rust | jiff | 0.2.41 | Unlicense OR MIT | https://github.com/BurntSushi/jiff |
| Rust | jiff-core | 0.1.4 | Unlicense OR MIT | https://github.com/BurntSushi/jiff |
| Rust | jiff-tzdb | 0.1.9 | Unlicense OR MIT | https://github.com/BurntSushi/jiff |
| Rust | jiff-tzdb-platform | 0.1.3 | Unlicense OR MIT | https://github.com/BurntSushi/jiff |
| Rust | json-patch | 4.2.0 | MIT/Apache-2.0 | https://github.com/idubrov/json-patch |
| Rust | jsonptr | 0.7.1 | MIT OR Apache-2.0 | https://github.com/chanced/jsonptr |
| Rust | keyboard-types | 0.7.0 | MIT OR Apache-2.0 | https://github.com/pyfisch/keyboard-types |
| Rust | keyboard-types | 0.8.3 | MIT OR Apache-2.0 | https://github.com/rust-windowing/keyboard-types |
| Rust | libbz2-rs-sys | 0.2.6 | bzip2-1.0.6 | https://github.com/trifectatechfoundation/libbzip2-rs |
| Rust | libc | 0.2.191 | MIT OR Apache-2.0 | https://github.com/rust-lang/libc |
| Rust | libloading | 0.8.9 | ISC | https://github.com/nagisa/rust_libloading/ |
| Rust | libsqlite3-sys | 0.39.1 | MIT | https://github.com/rusqlite/rusqlite |
| Rust | litemap | 0.8.3 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | lock_api | 0.4.14 | MIT OR Apache-2.0 | https://github.com/Amanieu/parking_lot |
| Rust | log | 0.4.35 | MIT OR Apache-2.0 | https://github.com/rust-lang/log |
| Rust | markup5ever | 0.39.0 | MIT OR Apache-2.0 | https://github.com/servo/html5ever |
| Rust | memchr | 2.8.3 | Unlicense OR MIT | https://github.com/BurntSushi/memchr |
| Rust | mime | 0.3.18 | MIT OR Apache-2.0 | https://github.com/hyperium/mime |
| Rust | minisign-verify | 0.3.0 | MIT | https://github.com/jedisct1/rust-minisign-verify |
| Rust | miniz_oxide | 0.8.9 | MIT OR Zlib OR Apache-2.0 | https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide |
| Rust | miniz_oxide | 0.9.1 | MIT OR Zlib OR Apache-2.0 | https://github.com/Frommi/miniz_oxide/tree/master/miniz_oxide |
| Rust | mio | 1.2.4 | MIT | https://github.com/tokio-rs/mio |
| Rust | moxcms | 0.8.1 | BSD-3-Clause OR Apache-2.0 | https://github.com/awxkee/moxcms.git |
| Rust | muda | 0.20.0 | Apache-2.0 OR MIT | https://github.com/tauri-apps/muda |
| Rust | new_debug_unreachable | 1.0.6 | MIT | https://github.com/mbrubeck/rust-debug-unreachable |
| Rust | notify-rust | 4.19.0 | MIT OR Apache-2.0 | https://github.com/hoodie/notify-rust |
| Rust | num-conv | 0.2.2 | MIT OR Apache-2.0 | https://github.com/jhpratt/num-conv |
| Rust | num-traits | 0.2.19 | MIT OR Apache-2.0 | https://github.com/rust-num/num-traits |
| Rust | once_cell | 1.21.4 | MIT OR Apache-2.0 | https://github.com/matklad/once_cell |
| Rust | option-ext | 0.2.0 | MPL-2.0 | https://github.com/soc/option-ext.git |
| Rust | parking_lot | 0.12.5 | MIT OR Apache-2.0 | https://github.com/Amanieu/parking_lot |
| Rust | parking_lot_core | 0.9.12 | MIT OR Apache-2.0 | https://github.com/Amanieu/parking_lot |
| Rust | percent-encoding | 2.3.2 | MIT OR Apache-2.0 | https://github.com/servo/rust-url/ |
| Rust | phf | 0.13.1 | MIT | https://github.com/rust-phf/rust-phf |
| Rust | phf_codegen | 0.13.1 | MIT | https://github.com/rust-phf/rust-phf |
| Rust | phf_generator | 0.13.1 | MIT | https://github.com/rust-phf/rust-phf |
| Rust | phf_macros | 0.13.1 | MIT | https://github.com/rust-phf/rust-phf |
| Rust | phf_shared | 0.13.1 | MIT | https://github.com/rust-phf/rust-phf |
| Rust | pin-project-lite | 0.2.17 | Apache-2.0 OR MIT | https://github.com/taiki-e/pin-project-lite |
| Rust | pkg-config | 0.3.34 | MIT OR Apache-2.0 | https://github.com/rust-lang/pkg-config-rs |
| Rust | plist | 1.10.3 | MIT | https://github.com/ebarnard/rust-plist/ |
| Rust | png | 0.18.1 | MIT OR Apache-2.0 | https://github.com/image-rs/image-png |
| Rust | potential_utf | 0.1.6 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | powerfmt | 0.2.1 | MIT OR Apache-2.0 | https://github.com/jhpratt/powerfmt |
| Rust | precomputed-hash | 0.1.1 | MIT | https://github.com/emilio/precomputed-hash |
| Rust | proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | https://github.com/dtolnay/proc-macro2 |
| Rust | pxfm | 0.1.30 | BSD-3-Clause OR Apache-2.0 | https://github.com/awxkee/pxfm |
| Rust | quick-xml | 0.42.0 | MIT | https://github.com/tafia/quick-xml |
| Rust | quote | 1.0.47 | MIT OR Apache-2.0 | https://github.com/dtolnay/quote |
| Rust | rand | 0.10.3 | MIT OR Apache-2.0 | https://github.com/rust-random/rand |
| Rust | rand_core | 0.10.1 | MIT OR Apache-2.0 | https://github.com/rust-random/rand_core |
| Rust | raw-window-handle | 0.6.2 | MIT OR Apache-2.0 OR Zlib | https://github.com/rust-windowing/raw-window-handle |
| Rust | ref-cast | 1.0.27 | MIT OR Apache-2.0 | https://github.com/dtolnay/ref-cast |
| Rust | ref-cast-impl | 1.0.27 | MIT OR Apache-2.0 | https://github.com/dtolnay/ref-cast |
| Rust | regex | 1.13.1 | MIT OR Apache-2.0 | https://github.com/rust-lang/regex |
| Rust | regex-automata | 0.4.18 | MIT OR Apache-2.0 | https://github.com/rust-lang/regex |
| Rust | regex-syntax | 0.8.11 | MIT OR Apache-2.0 | https://github.com/rust-lang/regex |
| Rust | reqwest | 0.13.5 | MIT OR Apache-2.0 | https://github.com/seanmonstar/reqwest |
| Rust | rfd | 0.18.0 | MIT | https://github.com/PolyMeilex/rfd |
| Rust | ring | 0.17.14 | Apache-2.0 AND ISC | https://github.com/briansmith/ring |
| Rust | roxmltree | 0.21.2 | MIT OR Apache-2.0 | https://github.com/RazrFalcon/roxmltree |
| Rust | rusqlite | 0.41.1 | MIT | https://github.com/rusqlite/rusqlite |
| Rust | rustc-hash | 2.1.3 | Apache-2.0 OR MIT | https://github.com/rust-lang/rustc-hash |
| Rust | rustc_version | 0.4.1 | MIT OR Apache-2.0 | https://github.com/djc/rustc-version-rs |
| Rust | rustls | 0.23.46 | Apache-2.0 OR ISC OR MIT | https://github.com/rustls/rustls |
| Rust | rustls-pki-types | 1.15.1 | MIT OR Apache-2.0 | https://github.com/rustls/pki-types |
| Rust | rustls-platform-verifier | 0.7.1 | MIT OR Apache-2.0 | https://github.com/rustls/rustls-platform-verifier |
| Rust | rustls-webpki | 0.103.16 | ISC | https://github.com/rustls/webpki |
| Rust | rustversion | 1.0.23 | MIT OR Apache-2.0 | https://github.com/dtolnay/rustversion |
| Rust | same-file | 1.0.6 | Unlicense/MIT | https://github.com/BurntSushi/same-file |
| Rust | schemars | 0.8.22 | MIT | https://github.com/GREsau/schemars |
| Rust | schemars | 0.9.0 | MIT | https://github.com/GREsau/schemars |
| Rust | schemars | 1.2.3 | MIT | https://github.com/GREsau/schemars |
| Rust | schemars_derive | 0.8.22 | MIT | https://github.com/GREsau/schemars |
| Rust | scopeguard | 1.2.0 | MIT OR Apache-2.0 | https://github.com/bluss/scopeguard |
| Rust | selectors | 0.38.0 | MPL-2.0 | https://github.com/servo/stylo |
| Rust | semver | 1.0.28 | MIT OR Apache-2.0 | https://github.com/dtolnay/semver |
| Rust | serde | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde |
| Rust | serde-untagged | 0.1.9 | MIT OR Apache-2.0 | https://github.com/dtolnay/serde-untagged |
| Rust | serde_core | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde |
| Rust | serde_derive | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde |
| Rust | serde_derive_internals | 0.29.1 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde |
| Rust | serde_json | 1.0.154 | MIT OR Apache-2.0 | https://github.com/serde-rs/json |
| Rust | serde_repr | 0.1.21 | MIT OR Apache-2.0 | https://github.com/dtolnay/serde-repr |
| Rust | serde_spanned | 1.1.3 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml |
| Rust | serde_with | 3.24.0 | MIT OR Apache-2.0 | https://github.com/jonasbb/serde_with/ |
| Rust | serde_with_macros | 3.24.0 | MIT OR Apache-2.0 | https://github.com/jonasbb/serde_with/ |
| Rust | serialize-to-javascript | 0.1.2 | MIT OR Apache-2.0 | https://github.com/chippers/serialize-to-javascript |
| Rust | serialize-to-javascript-impl | 0.1.2 | MIT OR Apache-2.0 | https://github.com/chippers/serialize-to-javascript |
| Rust | servo_arc | 0.4.3 | MIT OR Apache-2.0 | https://github.com/servo/stylo |
| Rust | sha2 | 0.10.9 | MIT OR Apache-2.0 | https://github.com/RustCrypto/hashes |
| Rust | shlex | 2.0.1 | MIT OR Apache-2.0 | https://github.com/comex/rust-shlex |
| Rust | simd-adler32 | 0.3.10 | MIT | https://github.com/mcountryman/simd-adler32 |
| Rust | siphasher | 1.0.4 | MIT OR Apache-2.0 | https://github.com/jedisct1/rust-siphash |
| Rust | slab | 0.4.12 | MIT | https://github.com/tokio-rs/slab |
| Rust | smallvec | 1.16.5 | MIT OR Apache-2.0 | https://github.com/servo/rust-smallvec |
| Rust | socket2 | 0.6.5 | MIT OR Apache-2.0 | https://github.com/rust-lang/socket2 |
| Rust | softbuffer | 0.4.8 | MIT OR Apache-2.0 | https://github.com/rust-windowing/softbuffer |
| Rust | stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 | https://github.com/storyyeller/stable_deref_trait |
| Rust | static_vcruntime | 3.0.0 | MIT OR Apache-2.0 OR Zlib | https://github.com/ChrisDenton/static_vcruntime |
| Rust | string_cache | 0.9.0 | MIT OR Apache-2.0 | https://github.com/servo/string-cache |
| Rust | string_cache_codegen | 0.6.1 | MIT OR Apache-2.0 | https://github.com/servo/string-cache |
| Rust | strsim | 0.11.1 | MIT | https://github.com/rapidfuzz/strsim-rs |
| Rust | subtle | 2.6.1 | BSD-3-Clause | https://github.com/dalek-cryptography/subtle |
| Rust | syn | 2.0.119 | MIT OR Apache-2.0 | https://github.com/dtolnay/syn |
| Rust | syn | 3.0.9 | MIT OR Apache-2.0 | https://github.com/dtolnay/syn |
| Rust | sync_wrapper | 1.0.2 | Apache-2.0 | https://github.com/Actyx/sync_wrapper |
| Rust | synstructure | 0.14.0 | MIT | https://github.com/mystor/synstructure |
| Rust | tao | 0.37.2 | Apache-2.0 | https://github.com/tauri-apps/tao |
| Rust | tar | 0.4.46 | MIT OR Apache-2.0 | https://github.com/composefs/tar-rs |
| Rust | tauri | 2.12.5 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-build | 2.7.4 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-codegen | 2.7.4 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-macros | 2.7.4 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-plugin | 2.7.2 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-plugin-global-shortcut | 2.4.1 | Apache-2.0 OR MIT | https://github.com/tauri-apps/plugins-workspace |
| Rust | tauri-plugin-notification | 2.8.0 | Apache-2.0 OR MIT | https://github.com/tauri-apps/plugins-workspace |
| Rust | tauri-plugin-single-instance | 2.5.5 | Apache-2.0 OR MIT | https://github.com/tauri-apps/plugins-workspace |
| Rust | tauri-plugin-updater | 2.14.1 | Apache-2.0 OR MIT | https://github.com/tauri-apps/plugins-workspace |
| Rust | tauri-runtime | 2.12.2 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-runtime-wry | 2.12.3 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-utils | 2.10.2 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri |
| Rust | tauri-winres | 0.3.7 | MIT | https://github.com/tauri-apps/winres |
| Rust | tauri-winrt-notification | 0.8.1 | MIT OR Apache-2.0 | https://github.com/tauri-apps/winrt-notification |
| Rust | tempfile | 3.27.0 | MIT OR Apache-2.0 | https://github.com/Stebalien/tempfile |
| Rust | tendril | 0.5.1 | MIT OR Apache-2.0 | https://github.com/servo/html5ever |
| Rust | thiserror | 2.0.21 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror |
| Rust | thiserror-impl | 2.0.21 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror |
| Rust | time | 0.3.55 | MIT OR Apache-2.0 | https://github.com/time-rs/time |
| Rust | time-core | 0.1.9 | MIT OR Apache-2.0 | https://github.com/time-rs/time |
| Rust | time-macros | 0.2.32 | MIT OR Apache-2.0 | https://github.com/time-rs/time |
| Rust | tinystr | 0.8.5 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | tinyvec | 1.13.3 | Zlib OR Apache-2.0 OR MIT | https://github.com/Lokathor/tinyvec |
| Rust | tokio | 1.54.1 | MIT | https://github.com/tokio-rs/tokio |
| Rust | tokio-macros | 2.7.2 | MIT | https://github.com/tokio-rs/tokio |
| Rust | tokio-rustls | 0.26.6 | MIT OR Apache-2.0 | https://github.com/rustls/tokio-rustls |
| Rust | tokio-util | 0.7.20 | MIT | https://github.com/tokio-rs/tokio |
| Rust | toml | 1.2.1+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml |
| Rust | toml_datetime | 1.1.3+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml |
| Rust | toml_parser | 1.1.5+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml |
| Rust | toml_writer | 1.2.0+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml |
| Rust | tower | 0.5.3 | MIT | https://github.com/tower-rs/tower |
| Rust | tower-http | 0.6.11 | MIT | https://github.com/tower-rs/tower-http |
| Rust | tower-layer | 0.3.3 | MIT | https://github.com/tower-rs/tower |
| Rust | tower-service | 0.3.3 | MIT | https://github.com/tower-rs/tower |
| Rust | tracing | 0.1.44 | MIT | https://github.com/tokio-rs/tracing |
| Rust | tracing-attributes | 0.1.31 | MIT | https://github.com/tokio-rs/tracing |
| Rust | tracing-core | 0.1.36 | MIT | https://github.com/tokio-rs/tracing |
| Rust | tray-icon | 0.25.1 | MIT OR Apache-2.0 | https://github.com/tauri-apps/tray-icon |
| Rust | try-lock | 0.2.5 | MIT | https://github.com/seanmonstar/try-lock |
| Rust | typed-path | 0.13.0 | MIT OR Apache-2.0 | https://github.com/chipsenkbeil/typed-path |
| Rust | typeid | 1.0.3 | MIT OR Apache-2.0 | https://github.com/dtolnay/typeid |
| Rust | typenum | 1.20.1 | MIT OR Apache-2.0 | https://github.com/paholg/typenum |
| Rust | unicode-ident | 1.0.27 | (MIT OR Apache-2.0) AND Unicode-3.0 | https://github.com/dtolnay/unicode-ident |
| Rust | unicode-segmentation | 1.13.3 | MIT OR Apache-2.0 | https://github.com/unicode-rs/unicode-segmentation |
| Rust | untrusted | 0.9.0 | ISC | https://github.com/briansmith/untrusted |
| Rust | url | 2.5.8 | MIT OR Apache-2.0 | https://github.com/servo/rust-url |
| Rust | urlpattern | 0.6.0 | MIT | https://github.com/denoland/rust-urlpattern |
| Rust | utf8_iter | 1.1.0 | Apache-2.0 OR MIT | https://github.com/hsivonen/utf8_iter |
| Rust | utf_types | 1.0.0 | Apache-2.0 OR MIT | https://github.com/hsivonen/utf_types |
| Rust | uuid | 1.29.1 | Apache-2.0 OR MIT | https://github.com/uuid-rs/uuid |
| Rust | vcpkg | 0.2.15 | MIT/Apache-2.0 | https://github.com/mcgoo/vcpkg-rs |
| Rust | version_check | 0.9.5 | MIT/Apache-2.0 | https://github.com/SergioBenitez/version_check |
| Rust | walkdir | 2.5.0 | Unlicense/MIT | https://github.com/BurntSushi/walkdir |
| Rust | want | 0.3.2 | MIT | https://github.com/seanmonstar/want |
| Rust | web-time | 1.1.0 | MIT OR Apache-2.0 | https://github.com/daxpedda/web-time |
| Rust | web_atoms | 0.2.6 | MIT OR Apache-2.0 | https://github.com/servo/html5ever |
| Rust | webview2-com | 0.39.1 | MIT | https://github.com/wravery/webview2-rs |
| Rust | webview2-com-macros | 0.8.1 | MIT | https://github.com/wravery/webview2-rs |
| Rust | webview2-com-sys | 0.39.1 | MIT | https://github.com/wravery/webview2-rs |
| Rust | winapi-util | 0.1.11 | Unlicense OR MIT | https://github.com/BurntSushi/winapi-util |
| Rust | window-vibrancy | 0.8.1 | Apache-2.0 OR MIT | https://github.com/tauri-apps/tauri-plugin-vibrancy |
| Rust | windows | 0.62.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-collections | 0.3.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-core | 0.62.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-future | 0.3.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-implement | 0.60.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-interface | 0.59.3 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-link | 0.2.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-numerics | 0.3.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-registry | 0.6.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-result | 0.4.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-strings | 0.5.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-sys | 0.59.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-sys | 0.61.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-targets | 0.52.6 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-threading | 0.2.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows-version | 0.1.7 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | windows_x86_64_gnu | 0.52.6 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs |
| Rust | winnow | 1.0.5 | MIT | https://github.com/winnow-rs/winnow |
| Rust | winreg | 0.56.0 | MIT | https://github.com/gentoo90/winreg-rs |
| Rust | writeable | 0.6.4 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | wry | 0.57.1 | Apache-2.0 OR MIT | https://github.com/tauri-apps/wry |
| Rust | yoke | 0.8.4 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | yoke-derive | 0.8.4 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zerofrom | 0.1.8 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zerofrom-derive | 0.1.8 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zeroize | 1.9.1 | Apache-2.0 OR MIT | https://github.com/RustCrypto/utils |
| Rust | zeroize_derive | 1.5.0 | Apache-2.0 OR MIT | https://github.com/RustCrypto/utils |
| Rust | zerotrie | 0.2.5 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zerovec | 0.11.9 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zerovec-derive | 0.11.7 | Unicode-3.0 | https://github.com/unicode-org/icu4x |
| Rust | zip | 9.5.0 | MIT | https://github.com/zip-rs/zip2 |
| Rust | zlib-rs | 0.6.8 | Zlib | https://github.com/trifectatechfoundation/zlib-rs |
| Rust | zmij | 1.0.23 | MIT | https://github.com/dtolnay/zmij |
| Rust | zopfli | 0.8.4 | Apache-2.0 | https://github.com/zopfli-rs/zopfli |
| npm | @tauri-apps/api | 2.12.4 | Apache-2.0 OR MIT | git+https://github.com/tauri-apps/tauri.git |
| npm | lucide-react | 1.70.0 | ISC | https://github.com/lucide-icons/lucide.git |
| npm | react | 19.3.1 | MIT | https://github.com/react/react.git |
| npm | react-dom | 19.3.1 | MIT | https://github.com/react/react.git |
| npm | scheduler | 0.28.0 | MIT | https://github.com/react/react.git |

## Voz opcional

Consulta `licenses/voice-components/README.md` para los motores y modelos descargables, sus licencias y sus fuentes correspondientes. La herramienta TTS se ejecuta como programa independiente y no se enlaza con QuickDeck.

Modelo local opcional: llama.cpp b12255 (MIT) y Qwen3-4B-Instruct-2507 Q4_K_M (modelo original Apache 2.0; cuantización publicada por LM Studio Community). Las licencias y referencias están en licenses/local-ai/. Los pesos se descargan por separado, con SHA-256 fijado, y no están incluidos en el instalador.

Detección de voz incorporada: Silero VAD v6.2.0 (MIT), conversión GGML publicada por ggml-org. El binario fijado de 885.098 bytes está incluido en el instalador y el portable. Consulta `licenses/silero-vad/` para la licencia, el origen y el hash.
