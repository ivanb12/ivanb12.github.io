# Silero VAD incorporado

Filtro local de presencia de voz, Silero v6.2.0 (MIT). El instalador y el portable incluyen una conversión GGML de 885.098 bytes. No descarga audio ni envía grabaciones a un servidor.

- Modelo: https://huggingface.co/ggml-org/whisper-vad/resolve/9ffd54a1e1ee413ddf265af9913beaf518d1639b/ggml-silero-v6.2.0.bin
- SHA-256: `2aa269b785eeb53a82983a20501ddf7c1d9c48e33ab63a41391ac6c9f7fb6987`.
- Proyecto original: https://github.com/snakers4/silero-vad
- Integración oficial utilizada: https://github.com/ggml-org/whisper.cpp/blob/v1.9.2/models/download-vad-model.sh
- Licencia original completa: `LICENSE`, obtenida del repositorio del autor.

Se utiliza con el motor Whisper existente y se verifica su integridad antes de cargarlo. No se bloquea la palabra «Suscríbete»: la presencia de voz se evalúa sobre el audio. Se mantienen las comprobaciones de confianza y la segunda pasada de reconocimiento.
