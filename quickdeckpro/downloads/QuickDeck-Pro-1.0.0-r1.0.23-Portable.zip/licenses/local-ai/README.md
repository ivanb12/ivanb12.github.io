# Modelo local de Gema

Motor llama.cpp b12255 (MIT): https://github.com/ggml-org/llama.cpp/tree/b12255

Modelo original Qwen3-4B-Instruct-2507 (Apache 2.0): https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507

Cuantización Q4_K_M publicada por LM Studio Community, revisión 4edb920b6f14e3b9284d4502a6485103d72cde05: https://huggingface.co/lmstudio-community/Qwen3-4B-Instruct-2507-GGUF

El instalador de QuickDeck no incluye los pesos. Su descarga es opcional, se fija por SHA-256 y conserva las licencias. El motor se ejecuta como proceso local sin privilegios.

Visión opcional: Qwen3-VL-2B-Instruct Q4_K_M y proyector Q8_0, publicados por Qwen bajo Apache-2.0. Fuente fijada: https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct-GGUF/tree/52d6c8ffea26cc873ac5ad116f8631268d7eb503 . Licencia: Qwen-Apache-2.0.txt. El motor llama.cpp usa la misma licencia MIT y compilación fijada b12255. Los pesos visuales se descargan por separado y no están incluidos en el instalador. El manifiesto contiene tamaños y SHA-256; no se cargan modelos o ejecutables indicados por una captura.
